const express = require('express');
const mongoose = require('mongoose');
const app = express();

// Middleware to parse JSON
app.use(express.json());

// Connect to MongoDB (replace '<Your_MongoDB_Connection_String>' with your connection string)
mongoose.connect('mongodb+srv://chloestanley2277:<db_password>@clusterapds.ob7zk.mongodb.net/?retryWrites=true&w=majority&appName=ClusterAPDS', { useNewUrlParser: true, useUnifiedTopology: true })
   .then(() => console.log('MongoDB Connected'))
   .catch(err => console.log(err));

// Basic route to test the server
app.get('/', (req, res) => {
   res.send('Hello World!');
});

// Start the server
app.listen(3000, () => {
   console.log('Server running on http://localhost:3000');
});
const authRoutes = require('./routes/auth');

// Use the auth routes
app.use('/api/auth', authRoutes);

 
